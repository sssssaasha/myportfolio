print("----| Menu Calculadora |----")
print("1 - somar")
print("2 - subtrair")
print("3 - multiplicar")
print("4 - dividir")
print("0 - sair")
menu = int(input("Digite a sua opção: "))

while menu!=0 and menu<=4:
    numeroUm = float(input("Digite o primeiro número: "))
    numeroDois = float(input("Digite o segundo número: "))

    if menu==1:
        print(f'{numeroUm} + {numeroDois} = {numeroUm+numeroDois}')

    elif menu==2:
        print(f'{numeroUm} - {numeroDois} = {numeroUm-numeroDois}')

    elif menu==3:
        print(f'{numeroUm} x {numeroDois} = {numeroUm*numeroDois}')

    elif menu==4:
        print(f'{numeroUm} / {numeroDois} = {numeroUm/numeroDois}')

    else:
        print("Encerrando a calculadora...")

    print("----| Menu Calculadora |----")
    print("1 - somar")
    print("2 - subtrair")
    print("3 - multiplicar")
    print("4 - dividir")
    print("0 - sair")
    menu = int(input("Digite a sua opção: "))

print("Encerrando a calculadora...")
